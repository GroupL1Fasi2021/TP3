﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace TP3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Garder la fenêtre active avec l'instruction Console.ReadKey() Qestion C

            /*System.Diagnostics.PerformanceCounter cpuFrequency;
            cpuFrequency = new PerformanceCounter();
            cpuFrequency.CategoryName = "Processor Information";
            cpuFrequency.CounterName = "Processor Frequency"; cpuFrequency.InstanceName = "0,0";
            Console.Write("Frequency of processor 0 is: ");
            Console.WriteLine(cpuFrequency.NextValue());*/

            /*Question D
             * Affichage d'une information au choix 
             * Affichage de la mémoire RAM utilisée lors de l'exécution
             */
            /*Process p = Process.GetCurrentProcess();  
            PerformanceCounter ramCounter = new PerformanceCounter("Process", "Working Set", p.ProcessName);
            PerformanceCounter cpuCounter = new PerformanceCounter("Process", "% Processor Time", p.ProcessName);
            int i = 0;
            while (i < 1)
            {
                
                Thread.Sleep(500);
                double ram = ramCounter.NextValue();
                double cpu = cpuCounter.NextValue();
                Console.WriteLine("RAM: "+(ram/1024/1024)+" MB; CPU: "+(cpu)+" %");
                i++;
               
               
            }*/

            /*Question E
             * Affichage du temps en milliseconde de l'exécution en cours d'xécution*/

            /*int i, c = 0;
            int timeLoop = Environment.TickCount & Int32.MaxValue;
            string username = Environment.UserName;

            for (i = 0; i < 1000000000; i++)
                c++;

            Console.WriteLine("Temps écoulé pour l'éxécution de la boucle: " + (Environment.TickCount - timeLoop));*/

            /*(Question F)
             * Affichage de l'identifiant du processus
             */
            /*string username = Environment.UserName;
            Process currentProcess = Process.GetCurrentProcess();
            Console.WriteLine("L'ID du processus courant est: " + currentProcess.Id + "\nNom du processus" + currentProcess.ProcessName);

            /*Question G
             *Affichage du nom de l'utilisateur
             */
            // Console.WriteLine("Le nom de l'utilisateur est: {0} ", username);

            /*Question H
             * Création d'un nouveau processus qui lance automatiquement bloc-notes* 
             */
            //Process notePad = Process.Start("notepad");

            /*Question I
             * Affichage du PID du nouveau processus en cours
             */
            //Console.WriteLine("L'ID du processus courant est: " + notePad.Id);

            /*Question J
             * Fermer le processus bloc-notes apès 5 sec
             */
            /*Thread.Sleep(2000);
            Process notePad = Process.Start("notepad");
            notePad.Kill();*/

            /*Question K
             * Lancer un autre processus B a partir du processus A 
             */
            /*ProcessStartInfo startinfo = new ProcessStartInfo(@"E:\workspace\Project_C#\DeuxiemeAppConsole\DeuxiemeAppConsole\bin\Debug\DeuxiemeAppConsole.exe");
            startinfo.UseShellExecute = true;
            Process p = Process.Start(startinfo);*/

            Console.ReadKey();
        }
    }
}
